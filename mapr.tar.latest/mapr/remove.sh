#!/bin/bash
dcos marathon app remove /comc1
dcos marathon app remove /data1
dcos marathon app remove /data2
dcos marathon app remove /data3
dcos marathon app remove /data4
