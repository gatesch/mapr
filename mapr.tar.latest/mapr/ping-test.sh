ansible mapr-all -m ping
